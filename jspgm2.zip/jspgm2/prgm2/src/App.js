import logo from './logo.svg';
import './App.css';
import Reg from './component/registration';



function App() {
  return (
    <>
    <Reg/>
    
    </>
  );
}

export default App;
