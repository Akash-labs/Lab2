import React, { Component } from 'react'

export default class registration extends Component {
   constructor(props){
       super(props)
           this.state={
               name:"",
               address:"",
               phone:"",
               results:""
           }
       
   }
   handleOnChangeaddress=(event) =>{
    this.setState(()=>({
         address:event.target.value
    }))
}
   handleOnChangename=(event)=>{
       this.setState(()=>({
            name:event.target.value
       }))
   }
   handleOnChangephone=(event) =>{
    this.setState(()=>({
         phone:event.target.value
    }))
}
   
  handlebutton=(event)=>{
      const result={
          name:this.state.name,
          address:this.state.address,
          phone:this.state.phone,
      }
      this.setState(()=>({
          results:result
      }))
  } 
    render() {
        return (
            <div>
                <div>
                    Name:<input type="text"  value={this.state.name} onChange={this.handleOnChangename}/>

                </div><br/>
                <div>
                   Address:<input type="text"  value={this.state.address} onChange={this.handleOnChangeaddress}/>

                </div><br />
                <div>
                   Phone:<input type="text"  value={this.state.phone} onChange={this.handleOnChangephone}/>

                </div><br />
                <div>
                    <button onClick={this.handlebutton}>click</button>
                </div>
                <div>
                    name={this.state.results.name}<br />
                    address={this.state.results.address}<br />
                    phone={this.state.results.phone}<br />
                </div>
            </div>
        )
    }
}
